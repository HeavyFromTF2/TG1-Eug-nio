#!/bin/bash

# Define o caminho para o arquivo de entrada
INPUT_FILE="../corpus/deu_mixed-typical_2011_300K-sentences.txt"

# Define o caminho para o arquivo de saida
OUTPUT_FILE="../words_dict/words.txt"

# Processa o arquivo de entrada para gerar uma lista ordenada de palavras e suas ocorrencias
# 1. Substitui os espaços entre as palavras por novas linhas para separar cada palavra
# 2. Converte todas as letras para minusculas para uniformidade
# 3. Filtra apenas palavras que tem caracteres alfabeticos e caracteres alemaes
# 4. Ordena as palavras alfabeticamente
# 5. Conta o numero de ocorrencias unicas de cada palavra
# 6. Ordena o arquivo de saida pela palavra (segunda coluna), para uniformidade na listagem
# 7. Inverte a ordem da saida para que cada linha tenha a palavra seguida da contagem de ocorrencias
# 8. Limita o resultado a 250.000 linhas para conter as palavras mais frequentes

tr -s ' ' '\n' < "$INPUT_FILE" | \
 tr '[:upper:]' '[:lower:]' | \
 grep -E '^[a-zA-Zäöüß]+$' | \
 sort | \
 uniq -c | \
 sort -k2 | \
 awk '{print $2, $1}' | \
 awk 'NR<=250000' > "$OUTPUT_FILE"


echo "The file was successfully created. Check the \"$OUTPUT_FILE\" for the results."
