#!/bin/bash

# Define o caminho para o arquivo de entrada
INPUT_FILE="../corpus_txt/deu_mixed_processed.txt"

# Define o caminho para o arquivo de saida
OUTPUT_FILE="../sentences_dict/sentences_pairs.txt"

# Processa o arquivo de entrada para gerar pares consecutivos de frases e as ocorrencias
# 1. Converte todas as letras para minusculas para uniformidade
# 2. Substitui todos os espaços nas frases pelo caractere '|'
# 3. Remove linhas vazias
# 4. Cria pares consecutivos de frases (frase1+frase2, frase2+frase3, etc...)
# 5. Ordena os pares de frases alfabeticamente
# 6. Conta as ocorrencias de cada par de frases
# 7. Limita o numero de pares para os primeiros 250.000 e inverte a ordem para mostrar o par antes da contagem

tr '[:upper:]' '[:lower:]' < "$INPUT_FILE" | \
  sed 's/ /|/g' | \
  grep -v '^$' | \
  awk '{print prev " " $0; prev=$0}' | \
  tail -n +2 | \
  sort | \
  uniq -c | \
  awk 'NR<=250000 {print $2, $3, $1}' > "$OUTPUT_FILE" 

echo "The file was successfully created. Check the \"$OUTPUT_FILE\" for the results."
