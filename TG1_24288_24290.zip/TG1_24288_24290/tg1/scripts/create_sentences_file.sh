#!/bin/bash

# Define o caminho para o arquivo de entrada
INPUT_FILE="../corpus_txt/deu_mixed_processed.txt"

# Define o caminho para o arquivo de saida
OUTPUT_FILE="../sentences_dict/sentences.txt"

# Processa o arquivo de entrada para gerar um arquivo com frases e suas contagens de ocorrencia
# 1. Converte todas as letras para minusculas para uniformidade
# 2. Substitui todos os espaços entre as palavras pelo caractere '|'
# 3. Remove linhas vazias
# 4. Ordena as frases alfabeticamente
# 5. Conta as ocorrencias de cada frase e organiza as mesmas
# 6. Ordena o resultado final pelas frases 
# 7. Limita o numero de frases a 250000

cat "$INPUT_FILE" | \
    tr '[:upper:]' '[:lower:]' | \
    sed 's/ /|/g' | \
    grep -v '^$' | \
    sort | \
    uniq -c | \
    awk '{print $2, $1}' | \
    sort | \
    awk 'NR<=250000' > "$OUTPUT_FILE"


echo "The file was successfully created. Check the \"$OUTPUT_FILE\" for the results."
