#!/bin/bash

# Define o caminho para o arquivo de entrada
INPUT_FILE="../corpus/deu_mixed-typical_2011_300K-sentences.txt"

# Define o caminho para o arquivo de saida
OUTPUT_FILE="../corpus_info/corpus_info.txt"

# Calcula o numero de caracteres no arquivo
echo -n "File characters:   " > "$OUTPUT_FILE"
tr -d '\n' < "$INPUT_FILE" | wc -m | cut -d' ' -f1 >> "$OUTPUT_FILE"

# Calcula o numero de linhas vazias
echo -n "Empty lines:  " >> "$OUTPUT_FILE"
grep -v "." "$INPUT_FILE" | wc -l | cut -d' ' -f1 >> "$OUTPUT_FILE"

# Calcula o numero total de palavras no arquivo
wordCount=$(tr -s " " '\n' < "$INPUT_FILE" | wc -l | cut -d' ' -f1)
echo "Total words:   $wordCount" >> "$OUTPUT_FILE"

# Calcula o numero de palavras unicas no arquivo
uniqueWordCount=$(tr -s " " '\n' < "$INPUT_FILE" | sort -u | wc -l | cut -d' ' -f1)
echo "Unique words:  $uniqueWordCount" >> "$OUTPUT_FILE"

# Calcula a razao de palavras unicas para palavras totais
wordRatio=$(echo "scale=2; $uniqueWordCount/$wordCount" | bc)
echo "Unique-to-total words ratio:   $wordRatio" >> "$OUTPUT_FILE"

# Calcula o numero total e unico de frases no arquivo
sentenceCount=$(tr -s '!.?' '\n' < "$INPUT_FILE" | wc -l | cut -d' ' -f1)
uniqueSentenceCount=$(tr -s '!.?' '\n' < "$INPUT_FILE" | sort -u | wc -l | cut -d' ' -f1)

echo "Total sentences:   $sentenceCount" >> "$OUTPUT_FILE"
echo "Unique sentences:  $uniqueSentenceCount" >> "$OUTPUT_FILE"

# Calcula a razao de frases unicas para frases totais
sentenceRatio=$(echo "scale=3; $uniqueSentenceCount/$sentenceCount" | bc)
echo "Unique-to-total sentences ratio:   $sentenceRatio" >> "$OUTPUT_FILE"

# Mensagem final para o terminal
echo "The file was successfully created. Check the "$OUTPUT_FILE" for the results."
