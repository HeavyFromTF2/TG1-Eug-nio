#!/bin/bash

# Caminhos para os arquivos
SENTENCES_FILE="../sentences_dict/sentences.txt"
PAIRS_FILE="../sentences_dict/sentences_pairs.txt"
OUTPUT_FILE="../sentences_dict/verify_sentences_pairs.txt"

# Verifica se os arquivos necessarios existem
if [[ ! -f "$SENTENCES_FILE" ]]; then
    echo "sentences.txt not found."
    exit 1
fi

if [[ ! -f "$PAIRS_FILE" ]]; then
    echo "sentences_pairs.txt not found."
    exit 1
fi

# Criar ou limpar o arquivo de saida
> "$OUTPUT_FILE"

echo "Both files have been found. Starting the comparing process..."

# Carregar as frases de sentences.txt em um array, substituindo espaços por '|'
declare -A sentences
while read -r line; do
    # Extrair a frase e substituir espaços por '|'
    sentence=$(echo "$line" | awk '{$NF=""; print $0}' | sed 's/ $//; s/ /|/g')
    # Adicionar a frase ao dicionario
    sentences["$sentence"]=1
done < "$SENTENCES_FILE"

# Processar os pares de frases em sentences_pairs.txt
while read -r line; do
    # Extrair as frases do par, substituir espaços internos por '|' e manter espaço unico entre as frases
    sentence1=$(echo "$line" | awk '{$NF=""; print $1}' | sed 's/ /|/g')
    sentence2=$(echo "$line" | awk '{$NF=""; print $2}' | sed 's/ /|/g')
    
    # Verificar se ambas as frases estao no dicionario
    if [[ -n "${sentences[$sentence1]}" && -n "${sentences[$sentence2]}" ]]; then
        echo "$sentence1 $sentence2 - Found sentences" >> "$OUTPUT_FILE"
    else
        echo "$sentence1 $sentence2 - Missing sentence(s)" >> "$OUTPUT_FILE"
    fi
done < "$PAIRS_FILE"


echo "Verification completed. Check the "$OUTPUT_FILE" for the final results."