#!/bin/bash

# Define o caminho para o arquivo de entrada
INPUT_FILE="../corpus/deu_mixed-typical_2011_300K-sentences.txt"

# Define o caminho para o arquivo de saida
OUTPUT_FILE="../corpus_txt/deu_mixed_processed.txt"

# Processa o arquivo de entrada removendo o numero da linha e espaços iniciais,
# e imprime o conteudo processado no arquivo de saida
gawk '{ $1=""; print substr($0, 2) }' "$INPUT_FILE" > "$OUTPUT_FILE"



echo "The file was successfully created. Check the "$OUTPUT_FILE" for the results."
