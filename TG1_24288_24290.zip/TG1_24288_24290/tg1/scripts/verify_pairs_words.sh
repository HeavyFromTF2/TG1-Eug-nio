#!/bin/bash

# Caminhos para os arquivos
WORDS_FILE="../words_dict/words.txt"
PAIRS_FILE="../words_dict/words_pairs.txt"
OUTPUT_FILE="../words_dict/verify_words_pairs.txt"

# Verifica se os arquivos necessarios existem
if [[ ! -f "$WORDS_FILE" ]]; then
    echo "words.txt was not found"
    exit 1
fi

if [[ ! -f "$PAIRS_FILE" ]]; then
    echo "words_pairs.txt was not found"
    exit 1
fi

# Criar ou limpar o arquivo de saida
> "$OUTPUT_FILE"

echo "Both files have been found. Starting the comparing process..."

# Carregar palavras de words.txt no dicionario, ignorando a contagem de ocorrencias
declare -A words
while read -r line; do
    # Extrai a palavra (o primeiro campo), remove espaços extras e caracteres especiais
    word=$(echo "$line" | awk '{print $1}' | sed 's/^[[:space:]]*//;s/[[:space:]]*$//')

    # Adiciona a palavra ao dicionario se nao for vazia
    if [[ -n "$word" ]]; then
        words["$word"]=1
    fi
done < "$WORDS_FILE"

# Processar os pares de palavras em words_pairs.txt
while read -r line; do
    # Extrai as palavras dos pares, ignorando o numero final, e limpa espaaos extras
    word1=$(echo "$line" | awk '{print $1}' | sed 's/^[[:space:]]*//;s/[[:space:]]*$//')
    word2=$(echo "$line" | awk '{print $2}' | sed 's/^[[:space:]]*//;s/[[:space:]]*$//')

    # Verificar se ambas as palavras estao no dicionario
    if [[ -n "${words[$word1]}" && -n "${words[$word2]}" ]]; then
        echo "$word1 $word2 - Words found" >> "$OUTPUT_FILE"
    else
        echo "$word1 $word2 - Missing word(s)" >> "$OUTPUT_FILE"
    fi
done < "$PAIRS_FILE"

echo "Verification completed. Check the \"$OUTPUT_FILE\" for the final results."
