#!/bin/bash

# Define o caminho para o arquivo de entrada
INPUT_FILE="../corpus_txt/deu_mixed_processed.txt"

# Define o caminho para o arquivo de saida
OUTPUT_FILE="../words_dict/words_pairs.txt"

# Processa o arquivo de entrada para gerar uma lista de pares consecutivos de palavras e suas ocorrências
# 1. Substitui os espaços entre as palavras por uma nova linha para separar las individualmente
# 2. Converte todas as letras para minusculas para uniformidade
# 3. Filtra apenas palavras alfabeticas (mantendo caracteres especiais do alemao)
# 4. Gera pares consecutivos de palavras (1+2, 2+3, 3+4, ...)
# 5. Ordena os pares de palavras alfabeticamente
# 6. Conta ocorrencias unicas de cada par de palavras
# 7. Ordena o arquivo final pelos pares de palavras (primeira e segunda palavra)
# 8. Inverte a ordem da saida para que cada linha tenha o par seguido pela contagem
# 9. Limita o resultado a 250.000 linhas, mantendo os pares de palavras mais frequentes

tr -s ' ' '\n' < "$INPUT_FILE" | \
  tr '[:upper:]' '[:lower:]' | \
  grep -E '^[a-zA-Zäöüß]+$' | \
  awk '{print prev " " $0; prev=$0}' | \
  tail -n +2 | \
  sort | \
  uniq -c | \
  awk '{print $2, $3, $1}' | \
  sort -k1,1 -k2,2 | \
  awk 'NR<=250000' > "$OUTPUT_FILE"


echo "The file was successfully created. Check the \"$OUTPUT_FILE\" for the results."
